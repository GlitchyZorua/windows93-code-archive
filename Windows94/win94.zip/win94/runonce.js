// Windows 94 Runonce Setup
//

window.$runOnce = ()=>{$notif("Welcome to Windows 94","Congratulations! You now have Windows 94 beta 1."),$store.del("win94/runonce.js"),delete window.$runOnce,$explorer.refresh()};