system42.on("splash:ready",function(){
  $explorer("/a/progman/Program Managar/")
setTimeout(function(){
  
  
  
  try{$window.instances[1].destroy()}catch{}
                     
                     
                     },1200)
})